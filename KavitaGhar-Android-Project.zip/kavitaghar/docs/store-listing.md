# Play Store listing: KavitaGhar / कविताघर

**App name (max 30):** KavitaGhar – कविताघर
**Category:** Books & Reference (ya Lifestyle) · **Free app, no ads**

## Short description (max 80)
- EN: Write, save and share your Hindi & English poems in beautiful fonts.
- HI: अपनी हिन्दी-अंग्रेज़ी कविताएँ सुंदर फ़ॉन्ट में लिखें, सहेजें और शेयर करें।

## Full description (English)
KavitaGhar is a home for your poems. Write directly in the app or turn a photo of a handwritten poem into text, then keep everything organised in one beautiful place.

• Hindi and English: read the whole app in either language, switch any time
• 10 hand-picked fonts: 6 Hindi, 4 English, each poem remembers its own font
• Categories: Love, Nature, Life, Sorrow, Patriotic, Other
• Favourites, search and a daily glimpse of one of your poems
• Share any poem as a pretty image card
• Dark and light themes
• Works offline. Your poems stay on your phone. No account, no ads
• Optional: read a poem from a photo (needs your own Claude API key)
• Backup and restore your poems

## Full description (Hindi)
कविताघर आपकी कविताओं का अपना घर है। ऐप में सीधे लिखें, या हाथ से लिखी कविता की फोटो को टेक्स्ट में बदलें, और सब कुछ एक सुंदर जगह सजाकर रखें।

• हिन्दी और English: पूरा ऐप किसी भी भाषा में पढ़ें, जब चाहें बदलें
• 10 चुनिंदा फ़ॉन्ट: 6 हिन्दी, 4 English, हर कविता अपना फ़ॉन्ट याद रखती है
• श्रेणियाँ: प्रेम, प्रकृति, जीवन, दर्द, देशभक्ति, अन्य
• पसंदीदा, खोज और आपकी एक कविता की रोज़ की झलक
• किसी भी कविता को सुंदर इमेज कार्ड बनाकर शेयर करें
• डार्क और लाइट थीम
• इंटरनेट के बिना भी चलता है। कविताएँ आपके फ़ोन में रहती हैं। न अकाउंट, न विज्ञापन
• वैकल्पिक: फोटो से कविता पढ़ना (अपनी Claude API Key चाहिए)
• बैकअप और वापस लाना

## Data safety form (Play Console): LOGIN + PUBLIC POSTS wala version
Ab app me khata aur public posts hain, isliye ye sahi jawab hain (neeche purani "None" wali lines sirf bina-login version ki thi):
- Collected: **Email address, Name (display name), User IDs, User-generated content (poems)**, sab **App functionality / Account management** ke liye.
- **Encrypted in transit:** Yes · **Users can request deletion:** Yes (Settings > Account me delete, aur privacy policy me email).
- Not shared with third parties for ads. (Firebase aapka service provider hai.)
- Optional photo feature: Photos, Anthropic ko user ki apni key se (optional).
- **UGC policy (zaroori):** Play ko report + block + hatane ki vyavastha dikhani hoti hai. App me Report, Block, Unpublish, Account delete maujood hain. Aapko Firebase console me **reports** collection ko roz dekhkar galat posts delete karni hongi.
- Play Console > App content me "Account deletion" ka web link bhi maanga jata hai: privacy policy ka link dekar usme email likha hai, behtar ho ek chhota alag page ban jaye.

## (Purana) Data safety, bina login version
Apni situation ke hisaab se jaanch kar bharo. Hamari jaankari ke mutabik:
- Data collected by you (developer): **None**, app ke servers hi nahi hain.
- Optional photo feature: photo user ki apni API key se seedhe Anthropic ko jati hai. Google ke niyam ke hisaab se isse "Photos" ko **third party ke saath shared, optional, in-transit encrypted** dikhana sabse surakshit hai. Agar aap ye feature release me na rakho to sab "No" ho sakta hai.
- Data deletion: user app me delete kar sakta hai / uninstall.
- Privacy policy URL: GitHub Pages wala link.

## Upload checklist
- [ ] App icon 512x512: `store/play-icon-512.png`
- [ ] Feature graphic 1024x500: `store/feature-graphic-1024x500.png`
- [ ] Phone screenshots (kam se kam 2): app phone me chalakar Home, Kavita page aur Image card ke screenshot lo
- [ ] Privacy policy link
- [ ] Content rating questionnaire (sab "No" rahega)
- [ ] Signed AAB upload
