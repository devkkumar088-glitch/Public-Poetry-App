import {initializeApp} from "firebase/app";
import {getAuth,onAuthStateChanged,createUserWithEmailAndPassword,signInWithEmailAndPassword,signOut,sendPasswordResetEmail,updateProfile,deleteUser,EmailAuthProvider,reauthenticateWithCredential} from "firebase/auth";
import {getFirestore,collection,doc,addDoc,setDoc,getDoc,getDocs,deleteDoc,query,where,orderBy,limit,serverTimestamp,arrayUnion} from "firebase/firestore";
// Firebase config (public identifiers, not secrets). If you later add a Web app in Firebase, replace appId with its web appId.
const cfg={apiKey:"AIzaSyCupdYxKkWpIyQpOmv52wQnqgX6iwovhc8",authDomain:"public-poetry-app.firebaseapp.com",projectId:"public-poetry-app",storageBucket:"public-poetry-app.firebasestorage.app",messagingSenderId:"137240669258",appId:"1:137240669258:android:2de5a80e88095e2cc50ab3"};
const app=initializeApp(cfg),auth=getAuth(app),db=getFirestore(app);
let blocked=[];
window.KFB={
  onAuth(cb){return onAuthStateChanged(auth,async u=>{blocked=[];if(u){try{const s=await getDoc(doc(db,"users",u.uid));blocked=(s.data()||{}).blocked||[]}catch(e){}}cb(u)})},
  async signUp(email,pw,name){const c=await createUserWithEmailAndPassword(auth,email,pw);await updateProfile(c.user,{displayName:name});await setDoc(doc(db,"users",c.user.uid),{name,blocked:[]});return c.user},
  signIn:(e,p)=>signInWithEmailAndPassword(auth,e,p),
  signOut:()=>signOut(auth),
  reset:e=>sendPasswordResetEmail(auth,e),
  async publish(p){const u=auth.currentUser;const r=await addDoc(collection(db,"posts"),{authorId:u.uid,authorName:u.displayName||"Poet",title:p.title||"",text:p.text,font:p.font,cat:p.cat,createdAt:serverTimestamp()});return r.id},
  unpublish:id=>deleteDoc(doc(db,"posts",id)),
  async feed(){const s=await getDocs(query(collection(db,"posts"),orderBy("createdAt","desc"),limit(50)));return s.docs.map(d=>({id:d.id,...d.data()})).filter(p=>!blocked.includes(p.authorId))},
  report:(postId,reason)=>addDoc(collection(db,"reports"),{postId,reporterId:auth.currentUser.uid,reason,createdAt:serverTimestamp()}),
  async block(uid){await setDoc(doc(db,"users",auth.currentUser.uid),{blocked:arrayUnion(uid)},{merge:true});blocked.push(uid)},
  async deleteAccount(pw){const u=auth.currentUser;await reauthenticateWithCredential(u,EmailAuthProvider.credential(u.email,pw));const s=await getDocs(query(collection(db,"posts"),where("authorId","==",u.uid)));for(const d of s.docs)await deleteDoc(d.ref);await deleteDoc(doc(db,"users",u.uid));await deleteUser(u)}
};
